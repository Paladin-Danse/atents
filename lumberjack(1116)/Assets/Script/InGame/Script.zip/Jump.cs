﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jump : MonoBehaviour {
    Vector2 pos;
    public float JumpPower;

    public float ray_Distance = 1.5f;
    Rigidbody2D rigidbody;
    Physics2D physics;

    int layer = 1 << 8;
    
    // Use this for initialization

    void Start() {
        rigidbody = GetComponent<Rigidbody2D>();
        
        layer = ~layer;
    }
	
	// Update is called once per frame
	void Update ()
    {
        Debug.DrawRay(transform.position, Vector2.down * ray_Distance, Color.yellow);
	}

    public void Player_Jump()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, ray_Distance, layer);
        
        if (hit.collider.tag == "Plan")
        {
            Debug.Log("Clear");
            rigidbody.AddForce(new Vector2(0, JumpPower));
        }
    }
}