﻿using UnityEngine;
using System.Collections;

public class Plan_Spawner : MonoBehaviour {
    public GameObject Plan;
    GameObject Next_Plan;

    public float Spawn_time;
    float _time;

    float Next_Plan_ScaleX;
    Vector2 Next_Plan_Position;
    
    // Use this for initialization
    void Start () {
        _time = Time.time;
        Plan_Data_Change(Plan);

        Plan_Change();
    }
	
	// Update is called once per frame
	void Update () {
	    
        if(Time.time >= _time + Spawn_time)
        {
            Plan_Change();

            _time = Time.time;
        }
        
	}

    void Plan_Change()
    {
        Next_Plan = Instantiate(Plan, Next_Plan_Position, Quaternion.identity) as GameObject;
        Plan = Next_Plan;
        Plan_Data_Change(Plan);
    }

    void Plan_Data_Change(GameObject Plan)
    {
        Next_Plan_ScaleX = Plan.transform.localScale.x;
        Next_Plan_Position = new Vector2(Plan.transform.position.x + (Next_Plan_ScaleX * (float)4.24), Plan.transform.position.y);//크기 오류시 수정
    }
}
